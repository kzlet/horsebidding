export interface Profile {
    username : string;
}